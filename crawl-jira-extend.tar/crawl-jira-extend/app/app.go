package app

import (
	"crawl-jira-extend/config"
	"crawl-jira-extend/controller"
	"crawl-jira-extend/service"
	"github.com/andygrunwald/go-jira"
	"github.com/globalsign/mgo"
	"google.golang.org/api/sheets/v4"
)

type CrawlJiraApp struct {
	db                  *mgo.Database
	jiraClient          *jira.Client
	config              *config.Config
	googleSheet         *sheets.Service
	crawlJiraController controller.ImplJiraController
}

func NewCrawlJiraApp(db *mgo.Database, jiraClient *jira.Client, config *config.Config, googleSheet *sheets.Service) *CrawlJiraApp {
	return &CrawlJiraApp{
		db:          db,
		jiraClient:  jiraClient,
		config:      config,
		googleSheet: googleSheet,
	}
}
func (app *CrawlJiraApp) InitServiceAndController() controller.ImplJiraController {
	jiraService := service.NewJiraService(app.db)
	app.crawlJiraController = controller.NewJiraController(app.jiraClient, jiraService,app.googleSheet)
	return app.crawlJiraController
}
