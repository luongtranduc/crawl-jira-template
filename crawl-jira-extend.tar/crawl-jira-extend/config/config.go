package config

import (
	"github.com/kelseyhightower/envconfig"
	"github.com/pkg/errors"
)

type Config struct {
	VinIDJiraUrl       string `envconfig:"VINID_JIRA_URL" required:"true" default:""`
	VinIDJiraUsername  string `envconfig:"VINID_JIRA_USERNAME" required:"true" `
	VinIDJiraPassword  string `envconfig:"VINID_JIRA_PASSWORD" required:"true"`
	MetaSpreadSheetID  string `envconfig:"META_SPREAD_SHEET_ID"  defautl:""`
	MonngoDBConnection string `envconfig:"MONGO_DB_CONNECTION" required:"true"`
	ScheduleTimeFirst  string `envconfig:"SCHEDULE_TIME_FIRST" required:"true" default:"@every 0h15m0s"`
	//ScheduleTimeSecond string `envconfig:"SCHEDULE_TIME_SECOND" required:"true" default:"CRON_TZ=Asia/Ho_Chi_Minh 0 13 * * *"`
}
func NewConfig() (*Config, error) {
	var config Config
	err := envconfig.Process("", &config)
	if err != nil {
		return nil, errors.Wrap(err, "load config fail")
	}

	return &config, nil
}
