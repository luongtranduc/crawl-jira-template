package constant

const (
	Database          = "jira-extend"
	CollectionBoard   = "board"
	CollectionProject = "project"
	CollectionSprint  = "sprint"
	CollectionIssue   = "issue"
	UploadRangeMeta   = "data!A2:R"
	MetaSpreadSheetID = ""
)
