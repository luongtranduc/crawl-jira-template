package controller

import (
	"crawl-jira-extend/dtos"
	"crawl-jira-extend/service"
	"crawl-jira-extend/utils"
	"github.com/andygrunwald/go-jira"
	"github.com/astaxie/beego/logs"
	"google.golang.org/api/sheets/v4"
	"strconv"
)

type ImplJiraController struct {
	jiraService service.JiraService
	jiraClient  *jira.Client
	googleSheet *sheets.Service
}

func NewJiraController(jiraClient *jira.Client, jiraService service.JiraService, googleSheet *sheets.Service) ImplJiraController {
	return ImplJiraController{jiraService: jiraService, jiraClient: jiraClient, googleSheet: googleSheet,
	}
}

func (c *ImplJiraController) InsertBoard() error {
	listProject, err := c.jiraService.ListAllProject()
	if err != nil {
		logs.Error("List project fail ", err)
		return err
	}
	for _, project := range listProject {
		// setup Option
		boardOption := jira.BoardListOptions{
			BoardType:      "scrum",
			ProjectKeyOrID: project.Key,
			SearchOptions: jira.SearchOptions{
				StartAt:    0,
				MaxResults: 100},
		}
		boardList, _, err := c.jiraClient.Board.GetAllBoards(&boardOption)
		if err != nil {
			logs.Error("Get board from jira api Fail: ", err)
			return err
		}
		for _, board := range boardList.Values {
			fetchInfo, _, err := c.jiraClient.Board.GetBoardConfiguration(board.ID)
			if err != nil {
				logs.Error("Get board configuration from jira api Fail")
				return err
			}
			boardExit, _ := c.jiraService.FindBoard(board.ID)
			if boardExit == nil {
				boardInsert := dtos.DtosBoardJiraToBoardClient(&board, project, fetchInfo.Location.ID)
				//Insert Data
				err = c.jiraService.InsertBoard(boardInsert)
				if err != nil {
					logs.Error("Insert board from jira api Fail")
					return err
				}
			}

			logs.Info("Insert board Success ", board.Name)
		}
	}

	return nil
}
func (c *ImplJiraController) InsertSprint() error {
	boardList, err := c.jiraService.ListBoard()
	if err != nil {
		logs.Error("List board fail: ,", err)
		return err
	}

	for _, board := range boardList {
		for i := 0; i < 3; i++ {
			option := jira.GetAllSprintsOptions{
				State: "closed",
				SearchOptions: jira.SearchOptions{
					StartAt:    50 * i,
					MaxResults: 50,
					Fields:     nil,
				},
			}
			sprintList, _, err := c.jiraClient.Board.GetAllSprintsWithOptions(board.ID, &option)
			if err != nil {
				logs.Error("Get sprint from board fail  ", err)
				return err
			}
			for _, sprint := range sprintList.Values {
				if sprint.OriginBoardID != board.ID {
					boardInfo, err := c.jiraService.FindBoard(sprint.OriginBoardID)
					if err != nil {
						continue
					} else {
						checkSprint, _ := c.jiraService.FindSprint(sprint.ID, boardInfo.ID)
						if checkSprint == nil {

							sprintInsert := dtos.DtosSprintJiraToSprintClient(&sprint, boardInfo)

							err := c.jiraService.InsertSprint(sprintInsert)
							if err != nil {
								logs.Error("Insert sprint fail: ", err)
								return err
							}
							logs.Info("Insert sprint %s ", sprint.Name)
						}
					}
				} else {
					checkSprint, _ := c.jiraService.FindSprint(sprint.ID, board.ID)
					if checkSprint == nil {
						sprintInsert := dtos.DtosSprintJiraToSprintClient(&sprint, board)
						err := c.jiraService.InsertSprint(sprintInsert)
						if err != nil {
							logs.Error("Insert sprint fail: ", err)
							return err
						}
						logs.Info("Insert sprint %s ", sprint.Name)
					}
				}
			}
			if len(sprintList.Values) < 50 {
				break
			}
		}
	}
	return nil
}
func (c *ImplJiraController) InsertIssue() error {
	sprintList, err := c.jiraService.ListSprint()
	if err != nil {
		logs.Error("Get sprint list Fail: ", err)
		return err
	}
	for _, sprint := range sprintList {
		for i := 0; i < 4; i++ {
			searchOption := jira.SearchOptions{
				StartAt:    100 * i,
				MaxResults: 100,
			}
			jqlIssueComplete := "issuetype in (Task, Story,Improvement) AND project = " + sprint.ProjectKey + " AND  status =  " + strconv.Quote("Closed") + " AND cf[10018] = " + strconv.Itoa(sprint.ID)
			issueList, _, err := c.jiraClient.Issue.Search(jqlIssueComplete, &searchOption)
			if err != nil {
				logs.Error("Get issue from Jira api Fail: ", err)
				return err
			}
			for _, issue := range issueList {
				issueInsert := dtos.DtosIssueJiraToIssueClient(&issue, sprint)
				err := c.jiraService.InsertIssue(issueInsert)
				if err != nil {
					logs.Error("Insert issue from jira Fail: ", err)
					return err
				}
				logs.Info("Insert issue Success: %s ", issueInsert.Key)
			}
			if len(issueList) < 100 {
				break
			}

		}
	}
	return nil
}
func (c *ImplJiraController) UploadGoogleSheet() error {
	issueList, err := c.jiraService.ListIssue()
	if err != nil{
		logs.Error("Get List Issue Fail: ",err)
		return err
	}
	// Parse data type to interface type
	var dataUpload [][] interface{}
	for _,issue := range issueList {
		issueAppend := []interface{} {issue.ID,issue.Assignee,issue.Key,issue.StoryPoint,issue.SprintName,issue.ProjectName}
		dataUpload = append(dataUpload, issueAppend)
	}
	err = utils.UploadDataFromLocal(c.googleSheet,dataUpload)
	if err != nil{
		logs.Error("Upload googleSheets  Fail" , err)
	}
	logs.Info("Upload google Success")
	return nil

}
