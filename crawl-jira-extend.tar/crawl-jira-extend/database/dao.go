package database

import (
	"crawl-jira-extend/constant"
	"crawl-jira-extend/model"
	"github.com/globalsign/mgo"
	"github.com/globalsign/mgo/bson"
)

type JiraDAO interface {
	ListAllProject() ([]*model.Project, error)
	InsertBoard(data interface{}) error
	ListBoard() ([]*model.Board, error)
	FindBoard(boardID int )(*model.Board, error)
	InsertSprint(data interface{}) error
	FindSprint(sprintId int ,boardId int) (*model.Sprint, error)
	UpdateSprint(legacy interface{}, new interface{}) error
	ListSprint() ([]*model.Sprint, error)
	InsertIssue(data interface{}) error
	ListIssue() ([]*model.Issue, error)
}
type implJiraDAO struct {
	collectionProject *mgo.Collection
	collectionBoard   *mgo.Collection
	collectionSprint  *mgo.Collection
	collectionIssue   *mgo.Collection
}


func NewJiraDAO(database *mgo.Database) JiraDAO {
	return &implJiraDAO{
		collectionProject: database.C(constant.CollectionProject),
		collectionBoard:   database.C(constant.CollectionBoard),
		collectionSprint:  database.C(constant.CollectionSprint),
		collectionIssue:   database.C(constant.CollectionIssue),
	}
}
func (d *implJiraDAO) ListIssue() ([]*model.Issue, error) {
	var listIssue []*model.Issue
	err := d.collectionIssue.Find(bson.M{}).All(&listIssue)
	if err != nil{
		return nil,err
	}
	return listIssue, nil
}

func (d *implJiraDAO) FindBoard(boardID int) (*model.Board, error) {
	var board *model.Board
	err := d.collectionBoard.Find(bson.M{"id":boardID}).One(&board)
	if err != nil{
		return nil,err
	}
	return board ,nil
}

func (d *implJiraDAO) FindSprint(sprintId int,boardID int) (*model.Sprint, error) {
	var sprint *model.Sprint
	err := d.collectionSprint.Find(bson.M{"id": sprintId,"boardid":boardID}).One(&sprint)
	if err != nil {
		return nil, err
	}
	return sprint, nil
}

func (d *implJiraDAO) ListAllProject() ([]*model.Project, error) {
	var projects []*model.Project
	err := d.collectionProject.Find(bson.M{}).All(&projects)
	if err != nil {
		return nil, err
	}
	return projects, nil
}
func (d *implJiraDAO) InsertBoard(data interface{}) error {
	err := d.collectionBoard.Insert(data)
	if err != nil {
		return err
	}
	return nil
}
func (d *implJiraDAO) ListBoard() ([]*model.Board, error) {
	var boards []*model.Board
	err := d.collectionBoard.Find(bson.M{"type": "scrum"}).All(&boards)
	if err != nil {
		return nil, err
	}
	return boards, nil
}
func (d *implJiraDAO) InsertSprint(data interface{}) error {
	err := d.collectionSprint.Insert(data)
	if err != nil {
		return err
	}
	return nil
}
func (d *implJiraDAO) UpdateSprint(legacy interface{}, new interface{}) error {
	err := d.collectionSprint.Update(legacy, new)
	if err != nil {
		return err
	}
	return nil
}
func (d *implJiraDAO) ListSprint() ([]*model.Sprint, error) {
	var sprints []*model.Sprint
	err := d.collectionSprint.Find(bson.M{"isnew": true}).All(&sprints)
	if err != nil {
		return nil, err
	}
	return sprints, nil
}
func (d *implJiraDAO) InsertIssue(data interface{}) error {
	err := d.collectionIssue.Insert(data)
	if err != nil {
		return err
	}
	return nil
}
