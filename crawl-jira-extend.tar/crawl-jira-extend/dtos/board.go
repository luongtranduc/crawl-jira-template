package dtos

import (
	"crawl-jira-extend/model"
	"github.com/andygrunwald/go-jira"
)

func DtosBoardJiraToBoardClient(board *jira.Board, project *model.Project,projectId string) model.Board  {
	return model.Board{
		ID:          board.ID	,
		Self:        board.Self,
		Name:        board.Name,
		Type:        board.Type,
		FilterID:    board.FilterID,
		ProjectID:   projectId,
		ProjectKey:  project.Key,
		ProjectName: project.Name,
	}
}
