package dtos

import (
	"crawl-jira-extend/model"
	"github.com/andygrunwald/go-jira"
)

func DtosIssueJiraToIssueClient(issue *jira.Issue, sprint *model.Sprint) model.Issue {
	storyPoint, _ := issue.Fields.Unknowns.Value("customfield_10023")
	var assignee, assigneeName string
	if issue.Fields.Assignee == nil {
		assignee = ""
		assigneeName = ""
	} else {
		assignee = issue.Fields.Assignee.EmailAddress
		assigneeName = issue.Fields.Assignee.Name

	}
	return model.Issue{
		ID:           issue.ID,
		Assignee:     assignee,
		AssigneeName: assigneeName,
		Key:          issue.Key,
		StoryPoint:   storyPoint,
		SprintName:   sprint.Name,
		BoardName:    sprint.BoardName,
		ProjectName:  sprint.ProjectName,
	}
}
