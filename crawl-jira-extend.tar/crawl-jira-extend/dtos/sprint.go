package dtos

import (
	"crawl-jira-extend/model"
	"github.com/andygrunwald/go-jira"
)

func DtosSprintJiraToSprintClient(sprint *jira.Sprint, board *model.Board) model.Sprint {
	var complete, startDate, endDate int64 = 0, 0, 0
	if sprint.CompleteDate != nil || sprint.EndDate != nil || sprint.StartDate != nil {
		complete = sprint.CompleteDate.Unix()
		startDate = sprint.StartDate.Unix()
		endDate = sprint.EndDate.Unix()
	}
	return model.Sprint{
		ID:            sprint.ID,
		Name:          sprint.Name,
		CompleteDate:  complete,
		EndDate:       startDate,
		StartDate:     endDate,
		OriginBoardID: sprint.OriginBoardID,
		Self:          sprint.Self,
		State:         sprint.State,
		BoardID:       board.ID,
		BoardName:     board.Name,
		ProjectName:   board.ProjectName,
		ProjectKey:    board.ProjectKey,
		IsNew:         true,
	}

}
