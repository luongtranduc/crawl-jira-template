package main

import (
	"crawl-jira-extend/app"
	"crawl-jira-extend/config"
	"crawl-jira-extend/utils"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/robfig/cron/v3"
)

func main() {
	cfg, err := config.NewConfig()
	if err != nil {
		panic(err)
	}
	db, err := utils.NewMongoDBConnection(cfg.MonngoDBConnection)
	if err != nil {
		panic(err)
	}
	jiraclient, err := utils.NewJiraConnection(cfg.VinIDJiraUrl, cfg.VinIDJiraUsername, cfg.VinIDJiraPassword)
	if err != nil {
		panic(err)
	}
	googleSheet, err := utils.NewGoogleSheetConnection()
	if err != nil {
		panic(err)
	}
	JiraCrawler := app.NewCrawlJiraApp(db, jiraclient, cfg, googleSheet)
	controller := JiraCrawler.InitServiceAndController()

	job := func() {
		//////Call function
		logs.Info("Insert Board process")
		err = controller.InsertBoard()
		if err != nil {
			panic(err)
		}
		logs.Info("Insert Sprint process")
		err = controller.InsertSprint()
		if err != nil {
			panic(err)
		}
		logs.Info("Insert Issue process")
		err = controller.InsertIssue()
		if err != nil {
			panic(err)
		}
		err = controller.UploadGoogleSheet()
		if err != nil {
			logs.Error(err)
			panic(err)
		}
		logs.Info("Upload GoogleSheets Success")
	}
	c := cron.New()
	_, err = c.AddFunc(cfg.ScheduleTimeFirst, job)

	if err != nil {
		fmt.Println(fmt.Sprintf("create new cron job error: %s", err.Error()))
	}
	c.Start()
	select {}

}
