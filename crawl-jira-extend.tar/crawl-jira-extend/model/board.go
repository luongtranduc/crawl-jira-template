package model

type Board struct {
	ID          int    `json:"id,omitempty"`
	Name        string `json:"name,omitempty"`
	Type        string `json:"type,omitempty"`
	ProjectName string `json:"project_name,omitempty"`
	ProjectKey  string `json:"project_key,omitempty"`
	ProjectID   string `json:"project_id,omitempty"`
	Self        string `json:"self,omitempty"`
	FilterID    int    `json:"filterId,omitempty"`
}
