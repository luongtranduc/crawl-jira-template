package model

type Issue struct {
	ID           string      `json:"id,omitempty"`
	Assignee     string      `json:"assignee"`
	AssigneeName string      `json:"assignee_name"`
	Key          string      `json:"key,omitempty"`
	StoryPoint   interface{} `json:"story_point,omitempty"`
	SprintName   string      `json:"sprint_name,omitempty"`
	BoardName    string      `json:"board_name"`
	ProjectName  string      `json:"project_name"`
}
