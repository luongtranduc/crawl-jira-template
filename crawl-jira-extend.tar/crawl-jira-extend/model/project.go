package model

type Project struct {
	Key string `json:"key"`
	Name string `json:"name"`
}
