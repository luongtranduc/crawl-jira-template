package model

type Sprint struct {
	ID            int    `json:"id"`
	Name          string `json:"name"`
	CompleteDate  int64  `json:"completeDate"`
	EndDate       int64  `json:"endDate"`
	StartDate     int64  `json:"startDate"`
	OriginBoardID int    `json:"originBoardId"`
	Self          string `json:"self"`
	State         string `json:"state"`
	BoardID       int    `json:"board_id"`
	BoardName     string `json:"board_name"`
	ProjectName   string `json:"project_name"`
	ProjectKey    string `json:"project_key"`
	IsNew         bool   `json:"is_new"`
}
