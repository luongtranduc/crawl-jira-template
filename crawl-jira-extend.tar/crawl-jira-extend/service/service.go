package service

import (
	"crawl-jira-extend/database"
	"crawl-jira-extend/model"
	"github.com/globalsign/mgo"
)

type JiraService interface {
	ListAllProject() ([]*model.Project, error)
	InsertBoard(data interface{}) error
	ListBoard() ([]*model.Board, error)
	FindBoard(boardId int) (*model.Board, error)
	InsertSprint(data interface{}) error
	UpdateSprint(legacy interface{}, new interface{}) error
	ListSprint() ([]*model.Sprint, error)
	InsertIssue(data interface{}) error
	ListIssue() ([]*model.Issue, error)
	FindSprint(sprintId int, boardId int) (*model.Sprint, error)
}
type implJiraService struct {
	jiraDAO database.JiraDAO
}



func NewJiraService(db *mgo.Database) JiraService {
	return &implJiraService{jiraDAO: database.NewJiraDAO(db)}
}
func (s *implJiraService) ListIssue() ([]*model.Issue, error) {
	return s.jiraDAO.ListIssue()
}
func (s *implJiraService) FindSprint(sprintId int, boardId int) (*model.Sprint, error) {
	return s.jiraDAO.FindSprint(sprintId, boardId)
}

func (s *implJiraService) ListAllProject() ([]*model.Project, error) {
	return s.jiraDAO.ListAllProject()
}

func (s *implJiraService) InsertBoard(data interface{}) error {
	return s.jiraDAO.InsertBoard(data)
}

func (s *implJiraService) ListBoard() ([]*model.Board, error) {
	return s.jiraDAO.ListBoard()
}
func (s *implJiraService) FindBoard(boardId int) (*model.Board, error) {
	return s.jiraDAO.FindBoard(boardId)
}
func (s *implJiraService) InsertSprint(data interface{}) error {
	return s.jiraDAO.InsertSprint(data)
}

func (s *implJiraService) UpdateSprint(legacy interface{}, new interface{}) error {
	return s.jiraDAO.UpdateSprint(legacy, new)
}

func (s *implJiraService) ListSprint() ([]*model.Sprint, error) {
	return s.jiraDAO.ListSprint()
}

func (s *implJiraService) InsertIssue(data interface{}) error {
	return s.jiraDAO.InsertIssue(data)
}
