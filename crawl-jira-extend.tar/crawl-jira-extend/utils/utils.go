package utils

import (
	"crawl-jira-extend/constant"
	"github.com/andygrunwald/go-jira"
	"github.com/globalsign/mgo"
	"golang.org/x/net/context"
	"golang.org/x/oauth2/google"
	"google.golang.org/api/sheets/v4"
	"io/ioutil"
	"log"
)
func NewMongoDBConnection(urlConnection string)(*mgo.Database, error)  {
	session, err := mgo.Dial(urlConnection)
	if err != nil {
		return nil, err
	}
	db := session.DB(constant.Database)
	return db, nil
}
func NewJiraConnection(url, username, password string) (*jira.Client, error){
	tp := jira.BasicAuthTransport{
		Username: username,
		Password: password,
	}
	jiraClient ,err:= jira.NewClient(tp.Client(), url)
	if err != nil{
		return  nil, err
	}
	return jiraClient, nil
}
func NewGoogleSheetConnection() (*sheets.Service, error) {
	b, err := ioutil.ReadFile("/secrets/credentials.json")
	if err != nil {
		log.Fatalf("Unable to read client secret file: %v", err)
	}

	// If modifying these scopes, delete your previously saved token.json.
	config, err := google.JWTConfigFromJSON(b, sheets.SpreadsheetsScope)
	if err != nil {
		log.Fatalf("Unable to parse client secret file to config: %v", err)
	}
	client := config.Client(context.Background())
	if err != nil {
		return nil, err
	}
	service, err := sheets.New(client)
	if err != nil {
		return nil, err
	}
	return service, nil
}
func UploadDataFromLocal(service *sheets.Service, data [][]interface{}) error {
	rb := &sheets.BatchUpdateValuesRequest{
		ValueInputOption: "USER_ENTERED",
	}
	rb.Data = append(rb.Data, &sheets.ValueRange{
		Range:           constant.UploadRangeMeta,
		Values:          data,
	})
	_, err := service.Spreadsheets.Values.BatchUpdate(constant.MetaSpreadSheetID,rb).Do()
	if err != nil {
		return err
	}
	return nil
}
